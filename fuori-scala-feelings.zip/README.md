# Fuori Scala Feelings

Sito interattivo per emozioni tessili.

## Pagine
- mood.html
- emotions.html
- pensieri.html
- ricerca.html

## Come usare
Carica tutto su GitHub Pages.